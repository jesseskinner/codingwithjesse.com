<pre><? print_r($_REQUEST); ?></pre>
