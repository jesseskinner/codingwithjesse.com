addDOMLoadEvent(function() {
	var SHOW_TEXT = '(show)';
	var HIDE_TEXT = '(hide)';
	// find extrainfo, if it doesn't exist, return	
	var extrainfo = $('extrainfo');
	if (!extrainfo) return;

	// find legend
	var legends = extrainfo.getElementsByTagName('legend');
	if (!legends.length) return;
	var legend = legends.item(0);

	// create show/hide "link"
	var showHide = document.createElement('span');
	showHide.className = 'show-hide';
	
	// add to legend
	legend.appendChild(showHide);
	
	addEvent(showHide, 'click', function() {
		var closed = toggleClassName(extrainfo, 'closed');
		if (closed) {
			showHide.innerHTML = SHOW_TEXT;
		} else {
			showHide.innerHTML = HIDE_TEXT;
		}
	});
	
	// start off with 'hide' text displayed
	showHide.innerHTML = HIDE_TEXT;
});