addDOMLoadEvent(function() {
	// get rid of no-spam checkbox
	var notspam = addform.notspam;
	if (!notspam) return;
	
	// remove entire label
	var notspam_label = notspam.parentNode;
	notspam_label.parentNode.removeChild(notspam_label);
	
	// add equivalent hidden input
	notspam = document.createElement('input');
	notspam.name = 'notspam';
	notspam.type = 'hidden';
	notspam.value = '1';
	addform.appendChild(notspam);
});
