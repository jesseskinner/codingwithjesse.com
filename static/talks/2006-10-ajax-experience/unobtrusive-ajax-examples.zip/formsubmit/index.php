<?php

require "../database.php";

if ($_POST['author'] && $_POST['body'] && $_POST['notspam']) {
	$author = addslashes($_POST['author']);
	$body = addslashes($_POST['body']);
	mysql_query("INSERT INTO comments (author, body) VALUES ('$author', '$body')");
}

$comments = mysql_query("SELECT * FROM comments ORDER BY date ASC");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Ajax Form Submit Demo</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../library.js"></script>
<script type="text/javascript" src="script.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="style.css"/>
</head>
<body>

<h1>Guestbook</h1>

<ol id="comments">
<?php while ($comment = mysql_fetch_object($comments)): ?>
	<li>
		<h2>By <?= $comment->author ?> at <?= date("g:ia, F jS, Y", strtotime($comment->date)) ?></h2>
		<p><?= $comment->body ?></p>
	</li>
<?php endwhile; ?>
</ol>

<form action="index.php" method="post" id="addform">
<label>
	Author
	<input type="text" name="author"/>
</label>
<label>
	Comment
	<textarea name="body"></textarea>
</label>
<label>
	<input type="checkbox" class="checkbox" name="notspam"/> Not Spam
</label>
<input type="submit" value="Save Comment"/>
</form>

</body>
</html>