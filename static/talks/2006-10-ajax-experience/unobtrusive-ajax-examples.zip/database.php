<?php

/*
CREATE TABLE `comments` (
  `id` int(11) NOT NULL auto_increment,
  `author` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

 */
 
mysql_connect("localhost", "root", "") or die ('Error: ' . mysql_error());
mysql_select_db("ajaxexperience");

?>
