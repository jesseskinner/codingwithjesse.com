function setText(text) {
	// find content area - if it doesn't exist, stop function
    var content = $('content');
	if (!content) return;

	content.innerHTML = text;
}

function linkClickAction(e) {
	// find surrounding ancestor elements
	var li = this.parentNode
	var navigation = li.parentNode;

	// reset any currently active tab
    var tabs = navigation.getElementsByTagName('li');
    for (var i=0;i < tabs.length;i++) {
        removeClassName(tabs[i], 'active');
    }
	
	// set clicked tab to active
    addClassName(li, 'active');

	// set temporary loading message
    setText('Loading...');
	
	// request content from server
    httpRequest(this.href + '&ajax=1', setText);
    
	// stop browser from following link
	preventDefault(e);
}

// attach event in separate function


addDOMLoadEvent(function() {
	// find navigation - if it doesn't exist, stop function
	var navigation = $('navigation');
	if (!navigation) return;
	
	// attach event to every link in the navigation
    var links = navigation.getElementsByTagName('a');
    for (var i=0;i < links.length;i++) {
		addEvent(links[i], 'click', linkClickAction);
    }
});
