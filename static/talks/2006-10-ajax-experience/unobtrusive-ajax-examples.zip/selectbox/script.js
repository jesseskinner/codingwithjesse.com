var category_data = [];

function updateSelects() {
	// find select boxes
	var category = $('category');
	var subcategory = $('subcategory');
	if (!category || !subcategory) return;

	// clear out select box
	while (subcategory.options.length > 0)
		subcategory.options[0] = null;

	// populate with sub-categories for this category
	for (var i=0;i < category_data.length;i++) {
		var item = category_data[i];
		if (item.main == category.options[category.selectedIndex].text) {
			var option = document.createElement('option');
			option.text = item.sub;
			option.value = item.id;
			subcategory.add(option, null);
		}
	}
}

addDOMLoadEvent(function() {
	// find subcategory select
	var subcategory = $('subcategory');
	if (!subcategory) return;
	
	var old_value = subcategory.options[subcategory.selectedIndex].value;

	// populate data model and new select box based on old one
	var category = document.createElement('select');
	category.id = 'category';
	var last = '';
	for (var i=0;i < subcategory.options.length;i++) {
		// split up label into category and subcategory
		var label = subcategory.options[i].text.split(' - ');
		
		// add data to array
		category_data.push({
			'id': subcategory.options[i].value,
			'main': label[0],
			'sub': label[1]
		});
		
		// if this is a new category, create a new option
		if (last != label[0]) {
			last = label[0];
			var option = document.createElement('option');
			option.text = label[0];
			category.add(option, null);
		}
		
		// if selected subcategory belongs to this category, select it
		if (subcategory.selectedIndex == i)
			category.options[category.options.length - 1].selected = true;
	}
	
	// add category select to page
	subcategory.parentNode.insertBefore(category, subcategory);

	// update second select box to match contents of first
	updateSelects();

	// add event to update second select box anytime first changes
	addEvent(category, 'change', updateSelects);
	
	// reset the selected 2nd-level select box item
	for (var i=0;i < subcategory.options.length;i++) {
		var option = subcategory.options[i];
		if (option.value == old_value) {
			option.selected = true;
			break;
		}
	}
})