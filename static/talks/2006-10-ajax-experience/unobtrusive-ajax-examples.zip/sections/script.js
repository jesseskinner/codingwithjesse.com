document.write('<link rel="stylesheet" type="text/css" media="screen" href="javascript.css"/>');

addDOMLoadEvent(function() {
	// find nav and sections, if they don't exist, return	
	var nav = $('nav');
	var sections = $('sections');
	if (!nav || !sections) return;

	// find actual sections
	var lis = sections.getElementsByTagName('li');
	if (!lis.length) return;
	
	// see if page url suggest a section should be active
	var href = window.location.href;
	var activeSection;
	if (href.indexOf('#') == -1) {
		// no section selected, make first one active
		activeSection = lis.item(0);
	} else {
		var id = href.substring(href.indexOf('#') + 1);
		activeSection = $(id);
	}
	addClassName(activeSection, 'active');	
	
	var links = nav.getElementsByTagName('a');
	for (var i=0;i < links.length;i++) {
		var link = links.item(i);
		addEvent(link, 'click', function(e) {
			for (var j=0;j < lis.length;j++) {
				var li = lis.item(j);
				removeClassName(li, 'active');
			}

			var id = this.href.substring(this.href.indexOf('#') + 1);
			addClassName($(id), 'active');
		});
	}
});