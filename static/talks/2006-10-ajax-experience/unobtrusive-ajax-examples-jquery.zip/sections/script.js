document.write('<link rel="stylesheet" type="text/css" media="screen" href="javascript.css"/>');

$(document).ready(function() {
	// see if page url suggest a section should be active
	var href = window.location.href;
	var activeSection;
	if (href.indexOf('#') == -1) {
		// no section selected, make first one active
		activeSection = $('#sections > li:first');
	} else {
		var id = href.substring(href.indexOf('#') + 1);
		activeSection = $('#sections li#' + id);
	}
	activeSection.addClass('active');

	$('#nav a').click(function() {
		$('#sections li').removeClass('active');

		var id = this.href.substring(this.href.indexOf('#') + 1);
		$('#' + id).addClass('active');
		
		return false;
	});
});