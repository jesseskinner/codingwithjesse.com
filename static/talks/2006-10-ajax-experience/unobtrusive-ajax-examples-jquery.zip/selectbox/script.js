var category_data = {};

$(document).ready(function() {
	// find subcategory select
	var subcategory = $('#subcategory').get(0);
	if (!subcategory) return;
	
	// populate data model and new select box based on old one
	var category = document.createElement('select');
	
	$.each(subcategory.options, function(i, option) {
		// split up label into category and subcategory
		var label = option.text.split(' - ');
		var main_label = label[0];
		var sub_label = label[1];
		
		// add data to array
		if (!category_data[main_label]) {
			category_data[main_label] = {};

			category.options[category.options.length] = new Option(main_label);
		}
		category_data[main_label][sub_label] = option.value;
	});
	
	// add category select to page
	$(subcategory).before(category);

	function updateSelects () {
		// clear out select box
		$(subcategory).empty();
	
		var selectedText = category.options[category.selectedIndex].text;
		
		// populate with sub-categories for this category
		$.each(category_data[selectedText], function(label, id) {
			subcategory.options[subcategory.options.length] = new Option(label, id);
		});
	}
	
	// add event to update second select box anytime first changes
	$(category).change(updateSelects);
	
	updateSelects();
});