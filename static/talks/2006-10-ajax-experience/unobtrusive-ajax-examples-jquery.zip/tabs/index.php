<?php

$tabs = array("Home", "Work", "School", "Garden", "Pub");
$tab_content = array(
    "There's no place like Home.",
    "All work and no play makes me a dull boy.",
    "School's out for summer!",
    "InAGaddaDaVida!",
    "Cheers to the beers!"
);

$active_tab = $tabs[0];
$content = $tab_content[0];

if (isset($_GET['tab'])) {
    $active_tab = $_GET['tab'];
    $index = array_search($active_tab, $tabs);
    if ($index === false) die;
    $content = $tab_content[$index];
}

if (isset($_GET['ajax'])) {
    echo $content;
    die;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Ajax Tabs Demo</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../jquery.js"></script>
<script type="text/javascript" src="script.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="style.css"/>
</head>
<body>

<ul id="navigation">
<?php foreach ($tabs as $i => $tab): ?>
	<li
		<? if ($tabs[$i] == $active_tab): ?>
			class="active"
		<? endif; ?>
	>
		<a href="index.php?tab=<?= $tabs[$i] ?>"><?= $tabs[$i] ?></a>
	</li>
<?php endforeach; ?>
</ul>

<p id="content"><?= $content ?></p>

</body>
</html>