$(document).ready(function() {
	$('#navigation a').click(function () {
		$('#navigation li.active').removeClass('active');
		$(this).parent().addClass('active');
	
		// set temporary loading message
	    $('#content').html('Loading...').load(this.href + '&ajax=1');
	    
		return false;
	});
});
