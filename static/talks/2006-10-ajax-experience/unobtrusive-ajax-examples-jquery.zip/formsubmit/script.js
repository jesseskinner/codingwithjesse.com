$(document).ready(function() {
	// remove entire label
	$('#addform input[@name=notspam]').parent().remove();
	
	// add equivalent hidden input
	$('#addform').append('<input type="hidden" name="notspam" value="1"/>');
});
