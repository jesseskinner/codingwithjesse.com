$(document).ready(function() {
	var SHOW_TEXT = '(show)';
	var HIDE_TEXT = '(hide)';

	var showHide = $(document.createElement('span'));
	showHide.addClass('show-hide');
	showHide.html(HIDE_TEXT);
	
	showHide.toggle(function() {
		$('#extrainfo').addClass('closed');
		showHide.html(SHOW_TEXT);
	}, function() {
		$('#extrainfo').removeClass('closed');
		showHide.html(HIDE_TEXT);
	});
	
	$('#extrainfo legend').append(showHide);
});